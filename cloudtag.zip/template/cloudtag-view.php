<?php
$liste = array(
	array(
		"name"    => "Football",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 0,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Tactique",
		"color"   => 4,
		"size"    => 3,
		"x"       => 2,
		"y"       => 65,
		"z"       => 15,
		"cat"     => 0,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Onze",
		"color"   => 4,
		"size"    => 3,
		"x"       => 65,
		"y"       => 15,
		"z"       => 0,
		"cat"     => 0,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "11",
		"color"   => 1,
		"size"    => 3,
		"x"       => 50,
		"y"       => 46,
		"z"       => 10,
		"cat"     => 0,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Losange",
		"color"   => 4,
		"size"    => 3,
		"x"       => 40,
		"y"       => 0,
		"z"       => - 5,
		"cat"     => 0,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Informations",
		"color"   => 2,
		"size"    => 2,
		"x"       => 5,
		"y"       => 76,
		"z"       => 15,
		"cat"     => 0,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Patience",
		"color"   => 4,
		"size"    => 4,
		"x"       => 21,
		"y"       => 66,
		"z"       => - 6,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Action",
		"color"   => 2,
		"size"    => 5,
		"x"       => 41,
		"y"       => 20,
		"z"       => 15,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Recul",
		"color"   => 4,
		"size"    => 4,
		"x"       => 60,
		"y"       => 20,
		"z"       => 10,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Confrontation",
		"color"   => 2,
		"size"    => 1,
		"x"       => 85,
		"y"       => 34,
		"z"       => 14,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Équité",
		"color"   => 1,
		"size"    => 5,
		"x"       => 37,
		"y"       => 53.5,
		"z"       => 6,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Stratégie",
		"color"   => 1,
		"size"    => 4,
		"x"       => 50,
		"y"       => 65,
		"z"       => - 10,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Éthique",
		"color"   => 2,
		"size"    => 4,
		"x"       => 28,
		"y"       => 75,
		"z"       => - 10,
		"cat"     => 1,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Pragmatisme",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 1,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Bon Principes",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 1,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Belles Valeurs",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 1,
		"nuage"   => 0,
		"tableau" => 1
	),

	array(
		"name"    => "Ressenti",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Intuition",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Ventre",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Coeur",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Émotionnel",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Raison",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 2,
		"nuage"   => 0,
		"tableau" => 1
	),

	array(
		"name"    => "Histoire",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 3,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Avenir",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 3,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Passé",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 3,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Futur",
		"color"   => 2,
		"size"    => 2,
		"x"       => 0,
		"y"       => 55,
		"z"       => 0,
		"cat"     => 3,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Projet",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 3,
		"nuage"   => 0,
		"tableau" => 1
	),

	array(
		"name"    => "Précisions",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Précision",
		"color"   => 2,
		"size"    => 2,
		"x"       => 85,
		"y"       => 53,
		"z"       => 7,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Détails Occurrences",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Données",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Statistiques",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Information",
		"color"   => 4,
		"size"    => 2,
		"x"       => 74,
		"y"       => 71,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Domaines",
		"color"   => 3,
		"size"    => 2,
		"x"       => 2,
		"y"       => 42,
		"z"       => - 10,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Sujets",
		"color"   => 1,
		"size"    => 2,
		"x"       => 66,
		"y"       => 10,
		"z"       => 15,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Détail",
		"color"   => 2,
		"size"    => 2,
		"x"       => 65,
		"y"       => 58,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Logique",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Cohérence",
		"color"   => 4,
		"size"    => 5,
		"x"       => 29,
		"y"       => 35,
		"z"       => 0,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Décisions",
		"color"   => 4,
		"size"    => 3,
		"x"       => 12,
		"y"       => 29.5,
		"z"       => - 10,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Décision",
		"color"   => 1,
		"size"    => 2,
		"x"       => 57,
		"y"       => 3,
		"z"       => 6,
		"cat"     => 4,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Transmission",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Existant",
		"color"   => 4,
		"size"    => 1,
		"x"       => 33,
		"y"       => 20,
		"z"       => 16,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Influences",
		"color"   => 3,
		"size"    => 1,
		"x"       => 68,
		"y"       => 39,
		"z"       => - 10,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Singularités",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Singularité",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Rassembler",
		"color"   => 1,
		"size"    => 1,
		"x"       => 21,
		"y"       => 64,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Trouver",
		"color"   => 4,
		"size"    => 1,
		"x"       => 36,
		"y"       => 32,
		"z"       => - 15,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Communiquer",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Transmettre",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 50,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Vivre Ensemble",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Équilibre",
		"color"   => 3,
		"size"    => 4,
		"x"       => 75,
		"y"       => 58,
		"z"       => 13,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Sport",
		"color"   => 4,
		"size"    => 5,
		"x"       => 13,
		"y"       => 50,
		"z"       => 0,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Artiste",
		"color"   => 1,
		"size"    => 1,
		"x"       => 32,
		"y"       => 6,
		"z"       => 8,
		"cat"     => 5,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Contestation",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Arguments",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Idées",
		"color"   => 1,
		"size"    => 3,
		"x"       => 2,
		"y"       => 35,
		"z"       => 15,
		"cat"     => 6,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Concepts",
		"color"   => 1,
		"size"    => 2,
		"x"       => 44,
		"y"       => 83,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Projet",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Projets",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Ergonomie",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Personnalisation",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 6,
		"nuage"   => 0,
		"tableau" => 1
	),

	array(
		"name"    => "Projets",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 7,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Équipes",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 7,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Équipe",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 7,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Individualités",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 7,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Individualité",
		"color"   => 2,
		"size"    => 4,
		"x"       => 30,
		"y"       => 8,
		"z"       => - 3,
		"cat"     => 7,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Collectif",
		"color"   => 4,
		"size"    => 5,
		"x"       => 64,
		"y"       => 42,
		"z"       => - 11,
		"cat"     => 7,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Spontanéité",
		"color"   => 1,
		"size"    => 1,
		"x"       => 0,
		"y"       => 0,
		"z"       => 0,
		"cat"     => 8,
		"nuage"   => 0,
		"tableau" => 1
	),
	array(
		"name"    => "Préparation",
		"color"   => 2,
		"size"    => 1,
		"x"       => 50,
		"y"       => 18,
		"z"       => 2,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Original",
		"color"   => 1,
		"size"    => 1,
		"x"       => 50,
		"y"       => 33,
		"z"       => 14,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Progrès",
		"color"   => 1,
		"size"    => 1,
		"x"       => 30,
		"y"       => 62,
		"z"       => 10,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Transcendance",
		"color"   => 2,
		"size"    => 1,
		"x"       => 11,
		"y"       => 83,
		"z"       => 15,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Plaisir",
		"color"   => 4,
		"size"    => 1,
		"x"       => 30,
		"y"       => 24,
		"z"       => - 10,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),
	array(
		"name"    => "Jouer",
		"color"   => 1,
		"size"    => 1,
		"x"       => 43,
		"y"       => 48,
		"z"       => - 4,
		"cat"     => 8,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Choix",
		"color"   => 2,
		"size"    => 2,
		"x"       => 55,
		"y"       => 48,
		"z"       => 3,
		"cat"     => 9,
		"nuage"   => 1,
		"tableau" => 1
	),

	array(
		"name"    => "Valeurs",
		"color"   => 2,
		"size"    => 3,
		"x"       => 18,
		"y"       => 20,
		"z"       => - 18,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Bons",
		"color"   => 2,
		"size"    => 4,
		"x"       => 18,
		"y"       => 41,
		"z"       => 10,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Belles",
		"color"   => 4,
		"size"    => 3,
		"x"       => 72,
		"y"       => 30,
		"z"       => - 17,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Ensemble",
		"color"   => 4,
		"size"    => 1,
		"x"       => 80,
		"y"       => 37,
		"z"       => 9,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Système",
		"color"   => 4,
		"size"    => 1,
		"x"       => 18,
		"y"       => 50,
		"z"       => 0,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Vivre",
		"color"   => 4,
		"size"    => 1,
		"x"       => 35,
		"y"       => 48,
		"z"       => 0,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Passé",
		"color"   => 4,
		"size"    => 2,
		"x"       => 44,
		"y"       => 52,
		"z"       => 5,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	),
	array(
		"name"    => "Principes",
		"color"   => 2,
		"size"    => 4,
		"x"       => 59,
		"y"       => 75,
		"z"       => - 5,
		"cat"     => 10,
		"nuage"   => 1,
		"tableau" => 0
	)

);
$listWord = array(
	array(
		"Football",
		"11",
		"Onze",
		"Système",
		"Tactique",
		"Systèmes",
		"Tactiques",
		"4 3 1 2",
		"Losange",
		"Informations",
		"Règles",
		"Lois",
		"Cosmos",
		"Symboles",
		"Symbole",
		"Losange",
		"Évoluer"
	),
	array(
		"Ballon<i class='space'></i>",
		"Cercle<i class='space'></i>",
		"Hexagone<i class='space'></i>",
		"Triangle<i class='space'></i>",
		"Vérité<i class='space'></i>",
		"Victoire<i class='space'></i>",
		"Subtile<i class='space'></i>",
		"Vitesse",
		"Rapidité<i class='space'></i>",
		"Apprentissage",
		"Compréhension<i class='space'></i>",
		"Lecture",
		"Expression<i class='space'></i>",
		"Cercle<i class='space'></i>",
		"Parfait<i class='space'></i>",
		"Ballon",
		"Rond<i class='space'></i>",
		"Globe<i class='space'></i>",
		"Grand<i class='space'></i>",
		"Grandir",
		"Gagner<i class='space'></i>",
		"Grandeur",
		"Grandiose<i class='space'></i>",
		"Beauté",
		"Sublime<i class='space'></i>",
		"Allure<i class='space'></i>",
		"Classe<i class='space'></i>",
		"Magnificence<i class='space'></i>",
		"Magnétisme<i class='space'></i>",
		"Vivant<i class='space'></i>",
		"Émaner",
		"Réceptionner<i class='space'></i>",
		"Donner",
		"Recevoir<i class='space'></i>",
		"Ouvrir<i class='space'></i>",
		"Triangulaire<i class='space'></i>",
		"Défendre",
		"Attaquer<i class='space'></i>",
		"Déployer",
		"Anticiper",
		"Déployer<i class='space'></i>",
		"Créer<i class='space'></i>",
		"Admirer<i class='space'></i>",
		"Tranquillité<i class='space'></i>",
		"Neutralité<i class='space'></i>",
		"Pensée",
		"Réflexion<i class='space'></i>",
		"Neutralité<i class='space'></i>",
		"Recul<i class='space'></i>",
		"Attente<i class='space'></i>",
		"Mouvement<i class='space'></i>",
		"Tranquille<i class='space'></i>",
		"À l’Affût<i class='space'></i>",
		"Quiétude<i class='space'></i>",
		"Agilité",
		"Habilités<i class='space'></i>",
		"Technicités<i class='space'></i>",
		"Douances",
		"Spécificités<i class='space'></i>",
		"Talents<i class='space'></i>",
		"Terrain<i class='space'></i>",
		"Intime",
		"Extérieur<i class='space'></i>",
		"Rectangle",
		"Rond Central<i class='space'></i>",
		"Surface<i class='space'></i>",
		"Cœur<i class='space'></i>",
		"Central",
		"Périphérique<i class='space'></i>",
		"Médian<i class='space'></i>",
		"Latéral",
		"Transversal<i class='space'></i>",
		"Bas",
		"Hauteur<i class='space'></i>",
		"Dimensions<i class='space'></i>",
		"Dimension<i class='space'></i>",
		"Horizon",
		"Horizons<i class='space'></i>",
		"Terrain<i class='space'></i>",
		"Buts<i class='space'></i>",
		"But",
		"Buts<i class='space'></i>",
		"Objectifs",
		"Idéaux<i class='space'></i>",
		"Idéal",
		"Pragmatisme<i class='space'></i>",
		"Volonté",
		"Abnégation<i class='space'></i>",
		"Confiance",
		"sans naïveté<i class='space'></i>",
		"Objectif",
		"Neutre<i class='space'></i>",
		"Comportements",
		"Attitudes<i class='space'></i>",
		"Relatif",
		"Absolu<i class='space'></i>",
		"Conciliable",
		"Unique<i class='space'></i>",
		"Intime",
		"Extérieur<i class='space'></i>",
		"Conscient",
		"Inconscient<i class='space'></i>",
		"Subconscient<i class='space'></i>",
		"Souveraineté",
		"Tolérance<i class='space'></i>",
		"Obstination",
		"Lâcher prise<i class='space'></i>",
		"Discernement",
		"Désillusionnement<i class='space'></i>",
		"Estime",
		"Talents<i class='space'></i>",
		"Humilité<i class='space'></i>",
		"Convictions",
		"Certitudes<i class='space'></i>",
		"Humilité<i class='space'></i>",
		"Modeste Rigueur",
		"Abondance<i class='space'></i>",
		"Humilité<i class='space'></i>",
		"Individuation<i class='space'></i>",
		"Ensemble<i class='space'></i>",
		"Partage<i class='space'></i>",
		"Partager<i class='space'></i>",
		"Considérer<i class='space'></i>",
		"Protéger<i class='space'></i>",
		"S’émerveiller",
		"Contempler<i class='space'></i>",
		"Protéger<i class='space'></i>",
		"Soutenir",
		"Supporter<i class='space'></i>",
		"Pardonner",
		"Souvenir<i class='space'></i>",
		"Rêver",
		"Songer<i class='space'></i>",
		"Chercher",
		"S’Orienter<i class='space'></i>",
		"Trouver<i class='space'></i>",
		"Attentif Attentive<i class='space'></i>",
		"Conscience<i class='space'></i>",
		"Effets Miroirs",
		"Effets Boomerang<i class='space'></i>",
		"Synchronicités<i class='space'></i>",
		"Exponentiel",
		"Exponentialité<i class='space'></i>",
		"Dimensions<i class='space'></i>",
		"Paradigmes<i class='space'></i>",
		"Paradoxes<i class='space'></i>",
		"Dualités<i class='space'></i>",
		"Opposés<i class='space'></i>",
		"Équilibre<i class='space'></i>",
		"Ressenti",
		"Intuition",
		"Ventre",
		"Cœur",
		"Émotionnel",
		"Raison<i class='space'></i>",
		"Lumière<i class='space'></i>",
		"Foi",
		"Sans Attentes<i class='space'></i>",
		"Esprit",
		"Matière<i class='space'></i>",
		"Lumière<i class='space'></i>",
		"Vertueux",
	),
	array(
		"Déterminismes",
		"Conséquences",
		"Évolution",
		"Origines",
		"Raisons",
		"Apparences",
		"Réalités",
		"Nature<i class='space'></i>",
		"Mentalité",
		"Tempérament",
		"Mental",
		"Lucidité",
		"Concentration",
		"Intelligence",
		"Nature",
		"Naturel",
		"Ouverture d’Esprit",
		"Adaptabilité",
		"Intégrité",
		"Souveraineté",
		"Adaptabilité",
		"Positivité",
		"Volonté",
		"Désirs",
		"Diplomatie",
		"Pédagogie",
		"Synthèse",
		"Conclusion",
		"Savoir",
		"Connaissance",
		"Culture",
		"Intelligence",
		"Valeurs",
		"Principes",
		"Intelligence",
		"Conscience"
	),
	array(
		"Holistique",
		"Informations",
		"Précisions",
		"Détails",
		"Occurrences",
		"Données",
		"Statistiques",
		"Données",
		"Informations",
		"Information",
		"Domaines",
		"Sujets",
		"Détails",
		"Informations",
		"Information",
		"Précision",
		"Détail",
		"Exhaustivité",
		"Information",
		"Logique",
		"Logiques",
		"Cohérences",
		"Décisions",
		"Décision",
		"Cohérence",
		"Décisions",
		"Cohérence",
		"Information",
		"Décision",
	),
	array(
		"Ergonomie",
		"Personnalisation"
	),
	array(
		"Constatations",
		"Origines",
		"Raisons",
		"Origines",
		"Raisons",
		"Arguments",
		"Factuel",
		"Hypothèses",
		"Théories",
		"Thèses",
		"Certitudes",
		"Convictions",
		"Thèses",
		"Idées",
		"Concepts",
		"Projet",
		"Projets",
	),
	array(
		"Décisions",
		"Choix"
	),
	array(
		"Ergonomie",
		"Personnalisation"
	),
	array(
		"Décisions",
		"Choix"
	),
	array(
		"Histoire",
		"Avenir",
		"Passé",
		"Futur",
		"Projet"
	),
	array(
		"Projets",
		"Individualités",
		"Équipes",
		"Divergences",
		"Convergences",
		"Intérêts",
		"Rapport Forces",
		"Rapport",
		"Niveau d’Énergie",
		"Rapport",
		"Niveau d’Humeurs",
		"Collectif",
		"Individualité",
		"Collectif<i class='space'></i>",
		"Concessions",
		"Sans Compromis",
		"Priorités",
		"Générales",
		"Priorités",
		"Spécifiques",
		"Compatibles",
		"Conciliables",
		"Décisions",
		"Choix"
	),
	array(
		"Ressenti",
		"Intuition",
		"Ventre",
		"Cœur",
		"Émotionnel",
		"Raison"
	),
	array(
		"Tranquillité<i class='space'></i>",
		"Neutralité<i class='space'></i>",
		"Pensée",
		"Réflexion<i class='space'></i>",
		"Neutralité<i class='space'></i>",
		"Recul<i class='space'></i>",
		"Attente<i class='space'></i>",
		"Mouvement<i class='space'></i>",
		"Tranquille<i class='space'></i>",
		"À l’Affût<i class='space'></i>",
		"Quiétude"
	),
	array(
		"Patience",
		"Action",
		"Recul",
		"Action",
		"Confrontation",
		"Recul",
		"Phases",
		"Étapes",
		"Phases",
		"Étapes",
		"Listes",
		"Plans",
		"Intuitions",
		"Intuitions",
		"Équité",
		"Stratégie",
		"Équité",
		"Éthique",
		"Pragmatisme",
		"Stratégie",
		"Spontanéité",
		"Fonction",
		"Dépassement",
		"Fonction",
		"Transcendance",
		"Spontanéité",
		"Sport<i class='space'></i>",
		"Concessions",
		"Sans Compromis",
		"Priorités",
		"Générales",
		"Priorités",
		"Spécifiques",
		"Compatibles",
		"Conciliables",
		"Décisions",
		"Choix"
	),
	array(
		"Ressenti",
		"Intuition",
		"Ventre",
		"Cœur",
		"Émotionnel",
		"Raison"
	),
	array(
		"Essai",
		"Tentative",
		"Aventure",
		"Stabilité",
		"Alternance",
		"Stabilité",
		"Régularité",
		"Rassurer",
		"Confirmation",
		"Transformation",
		"Révélation",
		"Aboutissement",
		"Concorde",
		"Réussite"
	),
	array(
		"Collectif",
		"Individualité",
		"Spontanéité",
		"Préparation",
		"Original",
		"Existant",
		"Progrès",
		"Transcendance",
		"Plaisir",
		"Jouer",
		"Sérieux",
		"Jeu",
		"Phases",
		"Étapes",
		"Moments",
		"Aboutissement",
		"Jeu"
	),
	array(
		"Ressenti",
		"Intuition",
		"Ventre",
		"Cœur",
		"Émotionnel",
		"Raison",
		"Empathie",
		"Compassion",
		"Sensibilité",
		"Sans Naïveté",
		"Sans Niaiserie",
		"Gestion",
		"Force",
		"Concentration",
		"Assumer",
		"Responsable",
		"Assumer",
		"Maturité",
		"Bons Principes",
		"Belles Valeurs",
		"Bienveillance",
		"Tolérance",
		"Empathie",
		"Compassion",
		"Loyauté",
		"Fidélité",
		"Pardon",
		"Mémoire",
		"Respect",
		"Souveraineté",
		"Équité",
		"Éthique",
		"Pragmatisme",
		"Stratégie",
		"Spontanéité",
		"Sport"
	),
	array(
		"Influences",
		"Singularités",
		"Singularité",
		"Cohérence",
		"Trouver",
		"Ressenti",
		"Intuition",
		"Ventre",
		"Cœur",
		"Émotionnel",
		"Raison",
		"Transmission",
		"Existant",
		"Influences",
		"Singularités",
		"Singularité",
		"Cohérence",
		"Original Non Formaté",
		"Rassembler",
		"Trouver",
		"Singularités",
		"Singularité",
		"Rassembler",
		"Transmission"
	),
	array(
		"Communiquer",
		"Étymologie",
		"Sémantique",
		"Transmettre",
		"Vivre Ensemble",
		"Équilibre",
		"Sport",
		"Artiste",
		"Équilibre"
	)
);
?>


<div class="vc_col-sm-7">
    <div id="cloudTitle">
        <h3>Nuages</h3>
    </div>
    <div id="cloudController">
        <button class="fontCloud">Changer la typographie</button>
        <button class="colorCloud">Changer la teinte</button>
    </div>
    <div id="cloudtag">

		<?php
		foreach ( $liste as $item ) {
			$color = "color-1";
			$size  = "s-1";

			switch ( $item["color"] ) {
				case 1 :
					$color = "color-1";
					break;
				case 2 :
					$color = "color-2";
					break;
				case 3 :
					$color = "color-3";
					break;
				case 4 :
					$color = "color-4";
					break;
			}
			switch ( $item["size"] ) {
				case 1 :
					$size = "s-1";
					break;
				case 2 :
					$size = "s-2";
					break;
				case 3 :
					$size = "s-3";
					break;
				case 4 :
					$size = "s-4";
					break;
				case 5 :
					$size = "s-5";
					break;
				case 6 :
					$size = "s-6";
					break;
			}

			$class = "tag " . $color . " " . $size;
			$style = "left:" . $item["x"] . "%;top:" . $item["y"] . "%; transform: rotate(" . $item["z"] . "deg);";

			if ( $item["nuage"] == 1 ) {
				echo "<p class='" . $class . "' style='" . $style . "'>" . $item["name"] . "</p>";
			}
		}




		?>

    </div>
</div>
<div class="vc_col-sm-5">
    <div id="arrayCloud">
        <h3>Recherche Google par mots-clés</h3>
        <hr>
        <div class="categories">
            <div class="left-categorie">
                <hr class="backgroundColor"/>
                <div class="block-all">
                    <?php foreach ($listWord as $cat){
	                    echo "<div class='category'>";
                        foreach ($cat as $word){
                            echo "<a href='https://www.google.fr/search?q=".strip_tags($word)."' target='_blank'>".$word."</a>";
                        }
                        echo "</div><hr/>";
                    } ?>

                </div>
            </div>
            <div class="right-categorie">
                <hr class="backgroundColor"/>
                <div class="block-all">
                    <?php foreach ($listWord as $cat){
	                    echo "<div class='category'>";
                        foreach ($cat as $word){
	                        echo "<a href='https://www.google.fr/search?q=".strip_tags($word)."' target='_blank'>".$word."</a>";
                        }
                        echo "</div><hr/>";
                    } ?>

                </div>
            </div>
        </div>
    </div>
</div>

